<nav>
  <ul>
    <li><a href="{{ route('home') }}">Home</a></li>
    <li><a href="{{ route('projects.index') }}">Projects</a></li>
    <li><a href="{{ route('emailcontacto') }}">Contactar</a></li>
  </ul>
</nav>

<h2>Nombre: {{$name}}</h2>
<h2>Email: {{$email}}</h2>
<h2>Mensaje: {{$msg}}</h2>

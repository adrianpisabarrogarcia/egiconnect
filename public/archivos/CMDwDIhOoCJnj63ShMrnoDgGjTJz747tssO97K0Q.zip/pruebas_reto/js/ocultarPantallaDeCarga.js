$(document).ready(function(){
    $(".animacion").show();
    setTimeout(function () {
        $(".animacion").hide();
    }, 800);
});

$(document).ready(function(){
    $("main").hide();
    setTimeout(function () {
        $("main").show();
    }, 800);
});

$(document).ready(function(){
    $("header").hide();
    setTimeout(function () {
        $("header").show();
    }, 800);
});
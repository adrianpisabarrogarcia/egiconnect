function validarDatos(){
    if (!validarUsuario()){
        return false;
    }else{
        if (!validarPass()){
            return false;
        }else{
            if (!validarNombre()){
                return false;
            }else{
                if (!validarApellidos()){
                    return false;
                }else{
                    if (!validarEmail()){
                        return false;
                    }else{
                        if (!validarTelefono()){
                            return false;
                        }else{
                            return true;
                        }
                    }
                }
            }
        }
    }
    return false;
}

function validarNombre(){
    nombre = $("#nombre").val();
    patron = RegExp("^[A-zÀ-ÿ]+([ ]+[A-zÀ-ÿ]+){0,}$");
    if (patron.test(nombre)){
        aplicarEstiloNormal("#nombre");
        return true;
    }
    aplicarEstiloError("#nombre");
   return false;
}

function validarApellidos(){
    apellidos = $("#apellidos").val();
    patron = RegExp("^[A-zÀ-ÿ]+([ ]+[A-zÀ-ÿ]+){0,}$");
    if (patron.test(apellidos)){
        aplicarEstiloNormal("#apellidos");
        return true;
    }else
    aplicarEstiloError("#apellidos");
    return false;
}

function validarPass(){
    return true;
    //TODO
    //Que la contraseña cumpla con un formato RegExp
    //Que la pass1 coincida con la pass2
}

function validarUsuario(){
    return true;
}

function validarEmail(){
    //aplicarEstiloError("#email");
    return true;
}

function validarTelefono(){
    return true;
}

function aplicarEstiloError(parametro){
    $(parametro).css("border-bottom","red solid 2px");
    $(parametro).focus();
}

function aplicarEstiloNormal(parametro){
    $(parametro).css("border-bottom","black solid 2px");
}

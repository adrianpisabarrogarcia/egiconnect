<?php

include "BBDD.php";

session_start();
session_destroy();
$tiempoAnimacion = 4;
$inicio = comprobarIntentoInicio($bd);
$mensajeInicio = "";
if (!$inicio){
    $tiempoAnimacion = 0;
    $mensajeInicio = "Usuario o contraseña incorrecta";
}



function comprobarIntentoInicio($bd){
    if(isset($_POST["usuario"]) && isset($_POST["pass"])){
        $contador = 0;
        foreach ($bd as $persona){
            $contador ++;
            if ($persona["usuario"] == $_POST["usuario"] && $persona["pass"] == $_POST["pass"]){
                session_start();
                $_SESSION["usuario"] = $persona;
                require "principal.php";
                die();
            }
        }
        if ($contador == count($bd)){
            return false;
        }
    }
    return true;
}

require "index_view.php";






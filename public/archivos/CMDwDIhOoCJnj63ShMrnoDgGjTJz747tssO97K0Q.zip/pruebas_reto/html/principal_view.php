<html>
<head>
    <title>Aergibide SL - Login</title>
    <link rel="icon" type="image/png" href="../images/logo_morado.png">
    <link rel="stylesheet" type="text/css" href="../css/general.css">
    <link rel="stylesheet" type="text/css" href="../css/animacion.css">
    <link rel="stylesheet" type="text/css" href="../css/principal.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="Equipo1"/>
    <meta name="copyright" content="Todos los derechos reservados a Aergibide SL"/>
</head>
<body>


<div class="animacion">
    <img src="../images/logo_blanco.png">
    <div class="loader"></div>
</div>



<main>
    <header>
        <nav id="menu">
            <div id="menuizq">
                <a href="principal.php"><img src="../images/logo_nombre.png"></a>
            </div>
            <div id="menuder">
                <div id="divbuscar">
                    <input type="text" id="buscador" name="buscador" placeholder="Buscar...">
                    <img src="../images/buscar.png">
                </div>

                <img src="../images/usuario.png" id="usuario">
            </div>
        </nav>
    </header>

    <div id="space"></div>


    <section id="news">
        <div id="etiquetas">
            <h1>TEMAS DE PREGUNTAS</h1>
            <div id="topics">
                <input type="button" name="button" value="Self">
                <input type="button" name="button" value="RelationShip">
                <input type="button" name="button" value="Data Science">
                <input type="button" name="button" value="Programming">
                <input type="button" name="button" value="Productibity">
                <input type="button" name="button" value="JavaScript">
                <input type="button" name="button" value="machine Learning">
                <input type="button" name="button" value="Politics">
                <input type="button" name="button" value="Health">
            </div>

            <div class="separador"></div>

            <ul id="listaEtiquetas">
                <li><a href="">Help</a></li>
                <li><a href="">Status</a></li>
                <li><a href="">Writers</a></li>
                <li><a href="">Blog</a></li>
                <li><a href="">Careers</a></li>
                <li><a href="">Privacy</a></li>
                <li><a href="">Terms</a></li>
                <li><a href="">About</a></li>
            </ul>

            <div class="separador"></div>

            <ul id="listaRedes">
                <li id="insta"><a href=""><img src="../images/instagram.png"></a></li>
                <li id="face"><a href=""><img src="../images/facebook.png"></a></li>
                <li id="yt"><a href=""><img src="../images/youtube.png"></a></li>
                <li id="twitter"><a href=""><img src="../images/twitter.png"></a></li>
            </ul>

        </div>

    </section>
</main>

</body>
<script src="../js/jquery-3.5.1.min.js"></script>
<script src="../js/ocultarPantallaDeCarga.js"></script>
</html>

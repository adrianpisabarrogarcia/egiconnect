<?php

session_start();
if (!isset($_SESSION["usuario"])){
    require "index.php";
    die();
}

require "principal_view.php";
die();

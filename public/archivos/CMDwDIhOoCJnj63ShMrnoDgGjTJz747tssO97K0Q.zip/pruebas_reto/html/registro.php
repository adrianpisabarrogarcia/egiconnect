<?php

include "BBDD.php";

comprobarRegistro($bd);

function comprobarRegistro($bd){
    if (isset($_POST["nombreRegistro"])){
        comprobarExistencia($bd);
        insertarUsuario($bd);
        require "index.php";
        die();
    }
}

function comprobarExistencia($bd){
    //TODO cuando tengamos la base de datos
    /* Que el usuario no este insertado
     * Que el correo no este insertado
     */
}

function insertarUsuario($bd){
    //TODO cuando tengamos la base de datos
    /* Cifrar la contraseña
     * Insertar el usuario
     * */
}

require "registro_view.php";
<?php

$bd = array(
    [
        "usuario" => "juan",
        "pass" => "12345"
    ],
    [
        "usuario" => "ivan",
        "pass" => "98765"
    ]
);

<html>
<head>
    <title>Aergibide SL - Register</title>
    <link rel="icon" type="image/png" href="../images/logo_morado.png">
    <link rel="stylesheet" type="text/css" href="../css/registro.css">
    <link rel="stylesheet" type="text/css" href="../css/animacion.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="Equipo1" />
    <meta name="copyright" content="Todos los derechos reservados a Aergibide SL" />
    <meta name="description" content="Pagina web de la empresa Aergibide en la cual se crean posts que suben los empleados."/>
</head>
<body>
<div class="animacion">
    <img src="../images/logo_blanco.png">
    <div class="loader"></div>
</div>
<main>
    <div id="logo">
        <a href="index.php"> <img src="../images/logo_nombre2.png" id="logoNombre"></a>
    </div>
    <form action="registro.php"  method="post" onsubmit="return validarDatos()">
        <fieldset  id="cuadro">
            <legend><img src="../images/user.png" id="foto"></legend>
            <label for="usuario"><p>Nombre de usuario:</p></label> <input type="text" id="usuario" name="usuarioRegistro">
            <label for="pass"><p>Contraseña:</p></label> <input type="password" id="pass" name="passRegistro">
            <label for="pass2"><p>Repite la constraseña:</p></label> <input type="password" id="pass2" >
            <label for="nombre"><p>Nombre:</p></label> <input type="text" id="nombre" name="nombreRegistro">
            <label for="apellidos"><p>Apellido:</p></label> <input type="text" id="apellidos" name="apellidosRegistro">
            <label for="email"><p>Correo:</p></label> <input type="email" id="email" name="emailRegistro">
            <label for="telefono"><p>Telefono:</p></label> <input type="tel" id="telefono" name="telefonoRegistro">
            <button type="submit">Register</button>
            </div>
        </fieldset>
    </form>
</main>
</body>
<script src="../js/jquery-3.5.1.min.js"></script>
<script src="../js/ocultarPantallaDeCarga.js"></script>
<script src="../js/registro.js"></script>
</html>

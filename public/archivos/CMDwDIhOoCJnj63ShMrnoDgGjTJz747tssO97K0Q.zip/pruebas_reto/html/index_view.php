<html>
<head>
    <title>Aergibide SL - Login</title>
    <link rel="icon" type="image/png" href="../images/logo_morado.png">
    <link rel="stylesheet" type="text/css" href="../css/style.css">
    <link rel="stylesheet" type="text/css" href="../css/animacion.css">
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="author" content="Equipo1" />
    <meta name="copyright" content="Todos los derechos reservados a Aergibide SL" />
    <meta name="description" content="Pagina web de la empresa Aergibide en la cual se crean posts que suben los empleados."/>
</head>
<body>
<div class="animacion">
    <img src="../images/logo_blanco.png">
    <div class="loader"></div>
</div>

<main style="animation-duration: <?= $tiempoAnimacion ?>s";>
    <!--Logo de la empresa-->
    <div id="logo">
        <div class="fondoSombra">
            <img src="../images/logo_blanco.png">
            <h1>AERGIBIDE SL</h1>
        </div>

    </div>
    <form action="index.php" method="post">

        <img src="../images/logo_nombre2.png" id="logoNombre">
        <fieldset id="cuadro">
            <legend><img src="../images/user.png"></legend>
            <!--Peticion de datos para iniciar sesion-->
            <div id="campoUsuario">
                <img src="../images/usuario.png">
                <input type="text" placeholder="Username" id="usuario" name="usuario">
            </div>
            <div id="campoPass">
                <img src="../images/pass.png">
                <input type="password" placeholder="Password" id="pass" name="pass">
            </div>
            <!--Boton para iniciar sesion-->
            <div class="button">
                <button onclick="">LOG IN</button>
                <!-- Mensaje de inicio de sesion erroneo -->
                <span><i><?= $mensajeInicio ?></i></span>
                <p>¿No tienes una cuenta en Aergibide?  <a href="registro.php">Registrate</a></p>
            </div>
        </fieldset>

    </form>
</main>
<!--Script de la pagina-->
</body>
</html>
